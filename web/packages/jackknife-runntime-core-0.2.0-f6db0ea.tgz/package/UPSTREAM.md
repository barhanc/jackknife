Source: https://github.com/software-mansion/runntime
Revision: f6db0ea8937f9208c28b8ea69a5fdd8a0bf4320c
Directory: packages/runntime/src/core
Unmodified source, bundled with TypeGPU kernels compiled at package-build time.
